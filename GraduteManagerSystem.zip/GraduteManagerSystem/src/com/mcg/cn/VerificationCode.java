package com.mcg.cn;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class VerificationCode extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final int width=60;
	public static final int height=20;
	

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		Graphics g=(Graphics) image.getGraphics();
		
		//���ñ���ɫ
		 setBackGround(g);
		 
		//���ñ߿�
		 setBorder(g);
		 
		//��������
		 drawRandomLine(g);
		 
		//д�����
		 String random=drawRandomNum((Graphics2D)g);
		 request.getSession().setAttribute("imagecheckcode", random);
		 //ͼ��д�������
		 response.setContentType("image/jpeg");
		 //�����������Ҫ����
		 response.setDateHeader("expries",-1);
		 response.setHeader("Cache-Control","no-cache");
		 response.setHeader("pragma","no-cache");
		 ImageIO.write(image, "jpg", response.getOutputStream());
		
	}


	private String  drawRandomNum(Graphics2D g) {
		// TODO Auto-generated method stub
		g.setColor(Color.RED);
		g.setFont(new Font("����",Font.BOLD,17));
		
		String base="\u7684\u4e00\u4e86\u662f\u6621\u4e0d\u5728\u4eba\u4eec\u6709\u6765\u4ed6\u8fd9\u4e0a\u7740\u4e2a\u5730\u5230\u5927";
		StringBuffer sn=new StringBuffer();
		
		
		int x=5;
		for(int i=0;i<2;i++){
			
			//int degree=new Random().nextInt()%30;//0-30
			String ch=base.charAt(new Random().nextInt(base.length()))+"";
			sn.append(ch);
			//g.rotate(degree*Math.PI/180, x,20 );//������ת�ĽǶ�
			g.drawString(ch, x, 20);
			//g.rotate(-degree*Math.PI/180, x, 20);
			x+=30; 
		}
		return sn.toString();
	}

	private void drawRandomLine(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.GREEN);
		for(int i=0;i<5;i++){
		   int x1=new Random().nextInt(width);
		   int y1=new Random().nextInt(height);
		   
		   int x2=new Random().nextInt(width);
		   int y2=new Random().nextInt(height);
		   g.drawLine(x1, y1, x2, y2);
		}
	}

	private void setBorder(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.BLUE);
		g.drawRect(1, 1, width-2,height-2 );
	}

	private void setBackGround(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
	}
	
	
    
}
