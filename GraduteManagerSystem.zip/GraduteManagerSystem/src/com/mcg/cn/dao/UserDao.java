package com.mcg.cn.dao;

import com.mcg.cn.model.Admin;
import com.mcg.cn.model.Department;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.model.Profession;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {

	public Admin Login(Connection conn,Admin admin) throws Exception{
		Admin resultAdmin =null;
		String sql="select * from Admin where adminName=? and password=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, admin.getAdminName());
		pstmt.setString(2, admin.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultAdmin = new Admin();
			resultAdmin.setAdminId(rs.getInt("adminId"));
			resultAdmin.setAdminNum(rs.getString("adminNum"));
			resultAdmin.setAdminName(rs.getString("adminName"));
			resultAdmin.setPassword(rs.getString("password"));
		}
		return resultAdmin;
	}
	
	/**
	 * ����ҵ�����õ�¼Ȩ��
	 * @param conn
	 * @param gradute
	 * @return
	 * @throws Exception
	 */
	public Gradute Login(Connection conn,Gradute gradute) throws Exception{
		Gradute resultGradute =null;
		String sql="select * from Gradute where stuName=? and password=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, gradute.getStuName());
		pstmt.setString(2, gradute.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultGradute =new Gradute();
			resultGradute.setStuId(rs.getInt("stuId"));
			resultGradute.setStuNum(rs.getString("stuNum"));
			resultGradute.setStuName(rs.getString("stuName"));
			resultGradute.setPassword(rs.getString("password"));
			resultGradute.setSex(rs.getString("sex"));
			resultGradute.setMajor(rs.getString("major"));
			resultGradute.setGradeClass(rs.getString("gradeClass"));
			resultGradute.setAddress(rs.getString("address"));
			resultGradute.setPhoneNum(rs.getString("phoneNum"));
			resultGradute.setPoliticsSta(rs.getString("politicsSta"));
			resultGradute.setStage(rs.getString("stage"));

		}
		return resultGradute;
	}
	
	/**����ʦ���õ�¼Ȩ��*
	 * @param conn
	 * @param profession
	 * @return
	 * @throws Exception
	 */
	
	public Profession Login(Connection conn,Profession profession) throws Exception{
		Profession  resultProfession =null;
		String sql="select * from Profession where proName=? and password=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, profession.getProName());
		pstmt.setString(2, profession.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultProfession =new Profession();
			resultProfession.setProId(rs.getInt("proId"));
			resultProfession.setProNum(rs.getString("proNum"));
			resultProfession.setProName(rs.getString("proName"));
			resultProfession.setPassword(rs.getString("password"));
			
		}
		return resultProfession;
	}
	
	/**
	 * ���������õ�¼Ȩ��
	 * @param conn
	 * @param department
	 * @return
	 * @throws Exception
	 */
	public Department Login(Connection conn,Department department) throws  Exception{
		Department  resultDepartment=null;
		String sql="select * from Department where deptName=? and password=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, department.getDeptName());
		pstmt.setString(2, department.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultDepartment = new Department();
			resultDepartment.setDeptId(rs.getInt("deptId"));
			resultDepartment.setDeptNum(rs.getString("deptNum"));
			resultDepartment.setDeptName(rs.getString("deptName"));
			resultDepartment.setPassword(rs.getString("password"));
		}
		return resultDepartment;
	}
	
	/**
	 * ���¹���Ա������
	 * @param conn
	 * @param adminName
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public int adminUpdate (Connection conn,String adminName,String password) throws Exception{
		String sql="update Admin set password=? where adminName=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setString(2, adminName);
		
		return pstmt.executeUpdate();
		
	}
	
	/**
	 * ���±�ҵ������
	 * @param conn
	 * @param graduteName
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public int graduteUpdate (Connection conn,String stuName,String password) throws Exception {
		String sql="update Gradute set password=? where stuName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setString(2, stuName);
		
		return pstmt.executeUpdate();
		
		
	}
	
	/**���½�ʦ����
	 * 
	 * @param conn
	 * @param proName
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public int professionUpdate(Connection conn,String proName, String password) throws Exception{
		String sql="update Profession set password=? where proName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setString(2, proName);
		return pstmt.executeUpdate();
		
	}
	
	
	/**���²�������
	 * 
	 * @param conn
	 * @param deptName
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public int department(Connection conn,String deptName,String password) throws Exception{
		String sql="update Department set password=? where deptName=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setString(2, deptName);
		return pstmt.executeUpdate();
	}
}
