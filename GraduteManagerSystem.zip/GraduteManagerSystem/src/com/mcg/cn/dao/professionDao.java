package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Profession;

public class professionDao {
	
	/**
	 * ��ѯ��ʦ��Ϣ
	 * 
	 * */
      public List<Profession> proshow(Connection conn) throws Exception {
    	  List<Profession> professions=new ArrayList<Profession>();
    	  String sql="select proId,proNum,proName,sex from Profession";
    	  PreparedStatement pstmt=conn.prepareStatement(sql);
    	  ResultSet rs=pstmt.executeQuery();
    	  while(rs.next()){
    		  Profession profession=new Profession();
    		  profession.setProId(rs.getInt("proId"));
    		  profession.setProNum(rs.getString("proNum"));
    		  profession.setProName(rs.getString("proName"));
    		  profession.setSex(rs.getString("sex"));
    		  
    		  professions.add(profession);
    	  }
    	  conn.close();
		  return professions;
		  
    	  
      }
      
      /**
       * ���ӽ�ʦ
       * 
       * */
      
      public int ProfessionAdd(Connection conn,Profession profession) throws Exception{
    	 String sql="insert into Profession(proNum,proName,password,sex) "
    	 		+ "values(?,?,?,?)";
    	 PreparedStatement pstmt=conn.prepareStatement(sql);
    	 pstmt.setString(1, profession.getProNum());
    	 pstmt.setString(2, profession.getProName());
    	 pstmt.setString(3, profession.getPassword());
    	 pstmt.setString(4, profession.getSex());
		 return pstmt.executeUpdate();
    	  
      } 
}