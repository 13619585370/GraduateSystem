package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mcg.cn.model.MajorGrade;

public class majorGradeDao {

	/**
	 * ��ѯѧ���ɼ�
	 * 
	 * */
	public MajorGrade majorGradeshow(Connection conn,String stuName) throws Exception{
		String sql="select * from MajorGrade where stuName=?";
		MajorGrade majorgradeshow=new MajorGrade();
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, stuName);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			majorgradeshow.setMajorgraId(rs.getString("majorgraId"));
			majorgradeshow.setStuName(rs.getString("stuName"));
			majorgradeshow.setcLanguage(rs.getString("cLanguage"));
			majorgradeshow.setJava(rs.getString("java"));
			majorgradeshow.setSoftEngin(rs.getString("softEngin"));
			majorgradeshow.setSqlServer(rs.getString("sqlServer"));
			majorgradeshow.setComputerOrg(rs.getString("computerOrg"));
			majorgradeshow.setComputerNet(rs.getString("computerNet"));
			majorgradeshow.setLinux(rs.getString("linux"));
			majorgradeshow.setOracle(rs.getString("oracle"));
		}
		
		return majorgradeshow;
		
	}
}
