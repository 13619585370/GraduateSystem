package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Practice;

public class PracticeDao {

	/**
	 * ѧ������ʵϰ��֤����
	 * */
	
	public int practiceAdd(Connection conn,Practice practice) throws Exception {
		String sql="insert into Practice (stuNum,stuName,major,gradeClass,praAddress,startDate,endDate,praContent,prove) "
				+ "values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, practice.getStuNum());
		pstmt.setString(2, practice.getStuName());
		pstmt.setString(3, practice.getMajor());
		pstmt.setString(4, practice.getGradeClass());
		pstmt.setString(5, practice.getPraAddress());
		pstmt.setString(6, practice.getStartDate());
		pstmt.setString(7, practice.getEndDate());
		pstmt.setString(8, practice.getPraContent());
		pstmt.setString(9, practice.getProve());
		
		return pstmt.executeUpdate();
		
	}
	
	/**
	 * ��ѯѧ��ʵϰ����Ϣ
	 * 
	 **/
	
	public List<Practice> practiceShow(Connection conn,String major) throws Exception{
		List<Practice> practices=new ArrayList<Practice>();
		String sql="select * from Practice where major=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, major);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			Practice practice=new Practice();
			practice.setStuNum(rs.getString("stuNum"));
			practice.setStuName(rs.getString("stuName"));
			practice.setMajor(rs.getString("major"));
			practice.setGradeClass(rs.getString("gradeClass"));
			practice.setPraAddress(rs.getString("praAddress"));
			practice.setStartDate(rs.getString("startDate"));
			practice.setEndDate(rs.getString("endDate"));
			practice.setPraContent(rs.getString("praContent"));
			practice.setProve(rs.getString("prove"));
			
			practices.add(practice);
		}
		return practices;
		
	}
}
