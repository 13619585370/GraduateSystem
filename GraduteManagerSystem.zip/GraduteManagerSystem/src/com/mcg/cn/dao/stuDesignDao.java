package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.model.stuDesign;

public class stuDesignDao {

	/**
	 * ��ѯѧ��ѡ�������Ŀ�����Ϣ
	 * 
	 * */
	public List<stuDesign> stuDesignShow(Connection conn,String proName) throws Exception {
		List<stuDesign> studesigns=new ArrayList<stuDesign>();
		String sql="select * from stuDesign where proName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, proName);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			stuDesign studesign=new stuDesign();
			studesign.setDesignId(rs.getInt("DesignId"));
			studesign.setDesignName(rs.getString("DesignName"));
			studesign.setStuName(rs.getString("stuName"));
			studesign.setProName(rs.getString("proName"));
			studesign.setDesignDate(rs.getString("DesignDate"));
			
			
			//���ӵ�����
			studesigns.add(studesign);
			//System.out.println("chaxhulai");
		}
		return studesigns;
		
	}
	
}
