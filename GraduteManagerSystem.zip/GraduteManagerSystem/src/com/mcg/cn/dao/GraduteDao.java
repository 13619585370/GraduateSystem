package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Gradute;

public class GraduteDao {
	
	/**
	 * ��ʾȫ��ѧ����Ϣ
	 * @param conn
	 * @return
	 * @throws Exception
	 */
	
     public List<Gradute> graduteshow(Connection conn) throws Exception{
    	 List<Gradute> gradutes=new ArrayList<Gradute>();
    	 //String sql="select stuId,stuNum,stuName,sex,major,gradeClass,address,phoneNum,politicsSta from Gradute";
    	 PreparedStatement pstmt=conn.prepareStatement("select * from Gradute");
    	 ResultSet rs=pstmt.executeQuery();
    	 while(rs.next()){
    		 Gradute gradute=new Gradute();
    		 gradute.setStuId(rs.getInt("stuId"));
    		 gradute.setStuNum(rs.getString("stuNum"));
    		 gradute.setStuName(rs.getString("stuName"));
    		 gradute.setSex(rs.getString("sex"));
    		 gradute.setMajor(rs.getString("major"));
    		 gradute.setGradeClass(rs.getString("gradeClass"));
             gradute.setAddress(rs.getString("address"));
             gradute.setPhoneNum(rs.getString("phoneNum"));
             gradute.setPoliticsSta(rs.getString("politicsSta"));
             
             gradutes.add(gradute);
    	 }
		 return gradutes; 
		 
     }
     
     /**
 	 * ����ѧ����Ϣ
 	 * @param conn
 	 * @return
 	 * @throws Exception
 	 */

     
     public int GraduteAdd(Connection conn,Gradute gradute) throws Exception{
    	 String sql="insert into Gradute(stuNum,stuName,password,sex,major,gradeClass,address,phoneNum,politicsSta,stage) "
    	 		+ "values(?,?,?,?,?,?,?,?,?,?)";
    	 PreparedStatement pstmt=conn.prepareStatement(sql);
    	 pstmt.setString(1, gradute.getStuNum());
    	 pstmt.setString(2, gradute.getStuName());
    	 pstmt.setString(3, gradute.getPassword());
    	 pstmt.setString(4, gradute.getSex());
    	 pstmt.setString(5, gradute.getMajor());
    	 pstmt.setString(6,gradute.getGradeClass());
    	 pstmt.setString(7,gradute.getAddress());
    	 pstmt.setString(8,gradute.getPhoneNum());
    	 pstmt.setString(9,gradute.getPoliticsSta());
    	 pstmt.setString(10, gradute.getStage());
		 return pstmt.executeUpdate();
		 
    	 
     }
     
     /**
      * �Ȳ�ѯ��
      * �޸�ѧ����Ϣ
      * 
      * */
     
     /**
      * Ϊ�޸Ķ���ѯ
      * */
     public Gradute graduteshowupdate(Connection conn,String stuNum) throws Exception{
    	 Gradute gradute=new Gradute();
    	 //String sql="select stuId,stuNum,stuName,sex,major,gradeClass,address,phoneNum,politicsSta from Gradute";
    	 PreparedStatement pstmt=conn.prepareStatement("select * from Gradute where stuNum=?");
    	 pstmt.setString(1,stuNum);
    	 ResultSet rs=pstmt.executeQuery();
    	 if(rs.next()){
    		 //Gradute gradute=new Gradute();
    		 //gradute.setStuId(rs.getInt("stuId"));
    		 gradute.setStuNum(rs.getString("stuNum"));
    		 gradute.setStuName(rs.getString("stuName"));
    		 gradute.setPassword(rs.getString("password"));
    		 gradute.setSex(rs.getString("sex"));
    		 gradute.setMajor(rs.getString("major"));
    		 gradute.setGradeClass(rs.getString("gradeClass"));
             gradute.setAddress(rs.getString("address"));
             gradute.setPhoneNum(rs.getString("phoneNum"));
             gradute.setPoliticsSta(rs.getString("politicsSta"));
             gradute.setStage(rs.getString("stage"));
             
             
    	 }
		 return gradute; 
		 
     }
     
     
    /**
     * �޸�ѧ����Ϣ
     * 
     * */
     
     public int GraduteModify(Connection conn,Gradute gradute ,String stuNum) throws Exception{
    	 String sql="update Gradute set stuNum=?,stuName=?,password=?,sex=?,major=?,gradeClass=?,"
    	 		+ "address=?,phoneNum=?,politicsSta=?,stage=? where stuNum=?";
    	 PreparedStatement pstmt=conn.prepareStatement(sql);
    	 pstmt.setString(11, stuNum);
    	 pstmt.setString(1, gradute.getStuNum());
    	 pstmt.setString(2, gradute.getStuName());
    	 pstmt.setString(3, gradute.getPassword());
    	 pstmt.setString(4, gradute.getSex());
    	 pstmt.setString(5, gradute.getMajor());
    	 pstmt.setString(6, gradute.getGradeClass());
    	 pstmt.setString(7, gradute.getAddress());
    	 pstmt.setString(8, gradute.getPhoneNum());
    	 pstmt.setString(9, gradute.getPoliticsSta());
    	 pstmt.setString(10, gradute.getStage());
		 return pstmt.executeUpdate();

     }
     
     
     /**
      * ɾ��ѧ����Ϣ
      * 
      * */
     
     public int GraduteDelete(Connection conn,String stuNum) throws Exception{
    	 String sql="delete from Gradute where stuNum=?";
    	 PreparedStatement pstmt=conn.prepareStatement(sql);
    	 pstmt.setString(1, stuNum);
		return pstmt.executeUpdate();
    	 
     }
}
