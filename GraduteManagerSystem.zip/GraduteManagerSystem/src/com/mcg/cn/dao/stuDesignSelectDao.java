package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.model.stuDesign;

public class stuDesignSelectDao {
	
	public List<GraduationDesign> designshow1(Connection conn,String symajor) throws Exception{
		List<GraduationDesign> prodesigns=new ArrayList<GraduationDesign>();
		String sql="select * from GraduationDesign where symajor=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, symajor);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			GraduationDesign graduteDesign=new GraduationDesign();
			graduteDesign.setDesignId(rs.getString("DesignId"));
			graduteDesign.setDesignName(rs.getString("DesignName"));
			graduteDesign.setStuName(rs.getString("stuName"));
			graduteDesign.setProName(rs.getString("proName"));
			graduteDesign.setDesignDate(rs.getString("DesignDate"));
			graduteDesign.setSymajor(rs.getString("symajor"));
			graduteDesign.setNanyi(rs.getString("nanyi"));
			graduteDesign.setRequire(rs.getString("require"));
			graduteDesign.setType(rs.getString("type"));
			graduteDesign.setScoure(rs.getString("scoure"));
			
			graduteDesign.setBsScore(rs.getString("bsScore"));
			graduteDesign.setLwScore(rs.getString("lwScore"));
			graduteDesign.setSumScore(rs.getString("sumScore"));
			
			//���ӵ�����
			prodesigns.add(graduteDesign);
			//System.out.println("chaxhulai");
		}
		return prodesigns;
		
	}
	
	
	/**
	 * ѧ��ѡ���ҵ�����Ŀ
	 * 
	 * */
	
	public int stuDesignAdd(Connection conn,stuDesign studesign) throws Exception{
		String sql="insert into stuDesign (DesignName,stuName,proName,designDate,symajor,type,nanyi,scoure) "
				+ "values(?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, studesign.getDesignName());
		pstmt.setString(2, studesign.getStuName());
		pstmt.setString(3, studesign.getProName());
		pstmt.setString(4, studesign.getDesignDate());
		pstmt.setString(5, studesign.getSymajor());
		pstmt.setString(6, studesign.getType());
		pstmt.setString(7, studesign.getNanyi());
		pstmt.setString(8, studesign.getScoure());
		return pstmt.executeUpdate();
		
	}
	

}
