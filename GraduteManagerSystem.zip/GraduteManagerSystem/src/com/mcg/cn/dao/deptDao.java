package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Department;

public class deptDao {
	
	/**
	 * ��ѯ������Ϣ
	 * */
      public List<Department> deptshow(Connection conn) throws Exception{
    	  List<Department> departments=new ArrayList<Department>();
    	  String sql="select * from Department";
    	  PreparedStatement pstmt=conn.prepareStatement(sql);
    	  ResultSet rs=pstmt.executeQuery();  
    	  while(rs.next()){
    		  Department department=new Department();
    		  department.setDeptId(rs.getInt("deptId"));
    		  department.setDeptNum(rs.getString("deptNum"));
    		  department.setDeptName(rs.getString("deptName"));
    		  
    		  departments.add(department);
    	  }
		  return departments;
    	  
      }
      
      /**
       * ���Ӳ���
       * */
      public int departmentAdd(Connection conn,Department department) throws Exception{
    	  String sql="insert into Department (deptNum,deptName,password) "
    	  		+ "values(?,?,?)";
    	  PreparedStatement pstmt=conn.prepareStatement(sql);
    	  pstmt.setString(1, department.getDeptNum());
    	  pstmt.setString(2, department.getDeptName());
    	  pstmt.setString(3, department.getPassword());
		  return pstmt.executeUpdate();
    	  
      }

}
