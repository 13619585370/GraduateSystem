package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Admin;

public class AdminDao {
    public Admin adminShow(Connection conn,String adminName) throws Exception{
    	String sql="select * from Admin where adminName=?";
    	PreparedStatement pstmt=conn.prepareStatement(sql);
    	pstmt.setString(1, adminName);
    	ResultSet rs=pstmt.executeQuery();
    	Admin admin=new Admin();
    	if(rs.next()){
            
    		admin.setAdminNum(rs.getString("adminNum"));
    		admin.setAdminName(rs.getString("adminName"));
    	}
    	return admin;
    	
    }
}
