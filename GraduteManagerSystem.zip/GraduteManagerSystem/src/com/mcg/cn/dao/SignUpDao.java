package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.SignUp;

public class SignUpDao {
	
	/**
	 * ѧ������ǩ����Ϣ
	 * 
	 * */
	
	public int signupAdd(Connection conn,SignUp signUp) throws Exception{
		String sql="insert into SignUp (stuNum,stuName,major,gradeClass,sex,phoneNum,address,signDate,idea,resignDate) "
				+ "values(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, signUp.getStuNum());
		pstmt.setString(2, signUp.getStuName());
		pstmt.setString(3, signUp.getMajor());
		pstmt.setString(4, signUp.getGradeClass());
		pstmt.setString(5, signUp.getSex());
		pstmt.setString(6, signUp.getPhoneNum());
		pstmt.setString(7, signUp.getAddress());
		pstmt.setString(8, signUp.getSignDate());
		pstmt.setString(9, signUp.getIdea());
		pstmt.setString(10, signUp.getResignDate());
		
		return pstmt.executeUpdate();
		
	}
	
	/**
	 * ��ѯ����ѧ���ĵ�ǩ����Ϣ
	 * 
	 * */
	
	public List<SignUp> proSignUpshow(Connection conn,String major,String stuName) throws Exception{
		List<SignUp> proSignups=new ArrayList<SignUp>();
		String sql="select * from SignUp where major=? or stuName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, major);
		pstmt.setString(2, stuName);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			SignUp signup=new SignUp();
			signup.setSignupId(rs.getString("signupId"));
			signup.setStuNum(rs.getString("stuNum"));
			signup.setStuName(rs.getString("stuName"));
			signup.setMajor(rs.getString("major"));
			signup.setGradeClass(rs.getString("gradeClass"));
			signup.setSex(rs.getString("sex"));
			signup.setPhoneNum(rs.getString("phoneNum"));
			signup.setAddress(rs.getString("address"));
			signup.setSignDate(rs.getString("signDate"));
			signup.setIdea(rs.getString("idea"));
			signup.setResignDate(rs.getString("resignDate"));
			
			proSignups.add(signup);
		}
	
		return proSignups;
		
	}
	
	
	/**
	 * ѧ�������Լ���������ѯ�Լ���ǩ����Ϣ
	 * 
	 * */
	
	public SignUp stuSignUpselect (Connection conn,String stuName) throws Exception {
		SignUp stuSignUp=new SignUp();
		String sql="select * from SignUp where stuName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, stuName);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			stuSignUp.setSignupId(rs.getString("signupId"));
			stuSignUp.setStuNum(rs.getString("stuNum"));
			stuSignUp.setStuName(rs.getString("stuName"));
			stuSignUp.setMajor(rs.getString("major"));
			stuSignUp.setGradeClass(rs.getString("gradeClass"));
			stuSignUp.setSex(rs.getString("sex"));
			stuSignUp.setPhoneNum(rs.getString("phoneNum"));
			stuSignUp.setAddress(rs.getString("address"));
			stuSignUp.setSignDate(rs.getString("signDate"));
			stuSignUp.setIdea(rs.getString("idea"));
			stuSignUp.setResignDate(rs.getString("resignDate"));
		}
		
		return stuSignUp;
		
	}

}
