package com.mcg.cn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.GraduationDesign;

public class ScoreDao {
    
	public List<GraduationDesign> designshow(Connection conn,String symajor) throws Exception{
		List<GraduationDesign> prodesigns=new ArrayList<GraduationDesign>();
		String sql="select * from GraduationDesign where symajor=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, symajor);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			GraduationDesign graduteDesign=new GraduationDesign();
			graduteDesign.setDesignId(rs.getString("DesignId"));
			graduteDesign.setDesignName(rs.getString("DesignName"));
			graduteDesign.setStuName(rs.getString("stuName"));
			graduteDesign.setProName(rs.getString("proName"));
			graduteDesign.setDesignDate(rs.getString("DesignDate"));
			graduteDesign.setSymajor(rs.getString("symajor"));
			graduteDesign.setNanyi(rs.getString("nanyi"));
			graduteDesign.setRequire(rs.getString("require"));
			graduteDesign.setType(rs.getString("type"));
			graduteDesign.setScoure(rs.getString("scoure"));
			graduteDesign.setBsScore(rs.getString("bsScore"));
			graduteDesign.setLwScore(rs.getString("lwScore"));
			graduteDesign.setSumScore(rs.getString("sumScore"));
			
			//���ӵ�����
			prodesigns.add(graduteDesign);
			//System.out.println("chaxhulai");
		}
		return prodesigns;
		
	}
	
	/**
	 * Ϊ���Ӷ� ��ѯ
	 * 
	 * */
	public List<GraduationDesign> designshow1(Connection conn,String proName) throws Exception{
		List<GraduationDesign> prodesigns=new ArrayList<GraduationDesign>();
		String sql="select * from GraduationDesign where proName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, proName);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			GraduationDesign graduteDesign=new GraduationDesign();
			graduteDesign.setDesignId(rs.getString("DesignId"));
			graduteDesign.setDesignName(rs.getString("DesignName"));
			graduteDesign.setStuName(rs.getString("stuName"));
			graduteDesign.setProName(rs.getString("proName"));
			graduteDesign.setDesignDate(rs.getString("DesignDate"));
			graduteDesign.setSymajor(rs.getString("symajor"));
			graduteDesign.setNanyi(rs.getString("nanyi"));
			graduteDesign.setRequire(rs.getString("require"));
			graduteDesign.setType(rs.getString("type"));
			graduteDesign.setScoure(rs.getString("scoure"));
			graduteDesign.setBsScore(rs.getString("bsScore"));
			graduteDesign.setLwScore(rs.getString("lwScore"));
			graduteDesign.setSumScore(rs.getString("sumScore"));
			
			//���ӵ�����
			prodesigns.add(graduteDesign);
			//System.out.println("chaxhulai");
		}
		return prodesigns;
		
	}
	
	
	
	/**
	 * ������Ŀ����������
	 * 
	 * */
	public int proDesginAdd(Connection conn,GraduationDesign progradutaDesign) throws Exception{
		String sql="insert into GraduationDesign (DesignName,proName,DesignDate,symajor,nanyi,type,scoure,bsScore,lwScore,sumScore,stuName) "
				+ "values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,progradutaDesign.getDesignName());
		pstmt.setString(2, progradutaDesign.getProName());
        pstmt.setString(3, progradutaDesign.getDesignDate());
        pstmt.setString(4, progradutaDesign.getSymajor());
        pstmt.setString(5, progradutaDesign.getNanyi());
        pstmt.setString(6, progradutaDesign.getType());
        pstmt.setString(7, progradutaDesign.getScoure());
		pstmt.setString(8, progradutaDesign.getBsScore());
		pstmt.setString(9, progradutaDesign.getLwScore());
		pstmt.setString(10, progradutaDesign.getSumScore());
		pstmt.setString(11,progradutaDesign.getStuName() );
		return pstmt.executeUpdate();
		
	}
	
	/**
	 * Ϊ�޸ı�����Ϣ����ѯ
	 * 
	 * */
	public GraduationDesign proDesignUpShow(Connection conn,String DesignName) throws Exception {
		String sql="select * from GraduationDesign where DesignName=?";
		GraduationDesign prodesign=new GraduationDesign();
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, DesignName);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			prodesign.setDesignId(rs.getString("DesignId"));
			prodesign.setDesignName(rs.getString("DesignName"));
			prodesign.setStuName(rs.getString("stuName"));
			prodesign.setProName(rs.getString("proName"));
			prodesign.setDesignDate(rs.getString("DesignDate"));
			prodesign.setSymajor(rs.getString("symajor"));
			prodesign.setNanyi(rs.getString("nanyi"));
			prodesign.setType(rs.getString("type"));
			prodesign.setScoure(rs.getString("scoure"));
			prodesign.setBsScore(rs.getString("bsScore"));
			prodesign.setLwScore(rs.getString("lwScore"));
			prodesign.setSumScore(rs.getString("sumScore"));
			
			
			//���ӵ�����
			//System.out.println("Ϊ�޸Ķ�����");
		}
		return prodesign;
	}
	
	
	/**
	 * �޸���ʦ�����ı�ҵ�����Ŀ����Ϣ
	 * 
	 * */
	public int prodesignUpdate(Connection conn,GraduationDesign prodesignUp,String DesignId) throws Exception{
		String sql="update GraduationDesign set DesignName=?,proName=?,DesignDate=?,symajor=?,nanyi=?,type=?,scoure=? where DesignId=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,prodesignUp.getDesignName() );
		pstmt.setString(2, prodesignUp.getProName());
		pstmt.setString(3, prodesignUp.getDesignDate());
		pstmt.setString(4, prodesignUp.getSymajor());
		pstmt.setString(5, prodesignUp.getNanyi());
		pstmt.setString(6, prodesignUp.getType());
		pstmt.setString(7, prodesignUp.getScoure());
		pstmt.setString(8, DesignId);
		
		return pstmt.executeUpdate();
		
	}
	
	/**
	 * ɾ����ʦ�����ı�ҵ�����Ŀ
	 * 
	 * */
	
	public int prodesignDelete(Connection conn,String DesignId) throws Exception{
		String sql="delete from GraduationDesign where DesignId=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,DesignId);
		return pstmt.executeUpdate();
		
	}
	
	
	/**
	 * ɾ����ͬ���ѧ��ѡ��
	 * 
	 * */
	
	public int prodesignDisDelete(Connection conn,String stuName) throws Exception{
		String sql="delete from stuDesign where stuName=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,stuName);
		
		
		return pstmt.executeUpdate();
		
	}
}
