package com.mcg.cn.web;

import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class TeaDesignAddServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	     doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		/**
		 * ��ʦ���ӱ�ҵ�����Ŀ
		 * 
		 * **/
		GraduationDesign progradutaDesign=new GraduationDesign();
		request.setCharacterEncoding("utf-8");
		
		progradutaDesign.setDesignName(request.getParameter("designName2").trim());
		progradutaDesign.setProName(request.getParameter("proName2").trim());
		progradutaDesign.setDesignDate(request.getParameter("designDate2").trim());
		progradutaDesign.setSymajor(request.getParameter("symajor").trim());
		progradutaDesign.setNanyi(request.getParameter("nanyi").trim());
		progradutaDesign.setType(request.getParameter("type").trim());
		progradutaDesign.setScoure(request.getParameter("scoure").trim());
		
		int count;
		try {
			count=designDao.proDesginAdd(dbUtil.getCon(), progradutaDesign);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("Profession/design/design_show.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	

	
}
