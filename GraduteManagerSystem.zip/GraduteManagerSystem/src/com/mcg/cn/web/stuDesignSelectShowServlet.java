package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.ScoreDao;
import com.mcg.cn.dao.stuDesignSelectDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class stuDesignSelectShowServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	stuDesignSelectDao studesignSelectDao=new stuDesignSelectDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		/*
		 * ��ѯ��ҵ��Ƶķ���
		 * 
		 * **/
		
		List<GraduationDesign> gradesigns=null;
		request.setCharacterEncoding("utf-8");
		try {
			
			System.out.println(request.getParameter("symajor15"));
			gradesigns=studesignSelectDao.designshow1(dbUtil.getCon(),request.getParameter("symajor15"));
			request.setAttribute("gradesign", gradesigns);
			request.getRequestDispatcher("Gradute/design/gra_design04.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	
}
