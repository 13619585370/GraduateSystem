package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.PracticeDao;
import com.mcg.cn.model.Practice;
import com.mcg.cn.util.DbUtil;

public class PracticeAddServlet extends HttpServlet{

	/**
	 * ѧ������ʵϰ��֤��Ϣ
	 */
	private static final long serialVersionUID = 1L;

	
	DbUtil dbUtil=new DbUtil();
	PracticeDao practiceDao=new PracticeDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		Practice practice=new Practice();
		practice.setStuNum(request.getParameter("stuNum20"));
		practice.setStuName(request.getParameter("stuName20"));
		practice.setMajor(request.getParameter("major20"));
		practice.setGradeClass(request.getParameter("gradeClass20"));
		practice.setPraAddress(request.getParameter("praAddress20"));
		practice.setStartDate(request.getParameter("startDate20"));
		practice.setEndDate(request.getParameter("endDate20"));
		practice.setPraContent(request.getParameter("praContent20"));
		practice.setProve(request.getParameter("prove20"));
		
		int count;
		try {
			count=practiceDao.practiceAdd(dbUtil.getCon(), practice);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("Gradute/practice/aplyPractice1.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
