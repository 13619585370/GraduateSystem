package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class TeaDesignUpdateServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	/**
	 * �޸���ʦ�����ı�ҵ�����Ŀ��Ϣ
	 * 
	 * */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");
		GraduationDesign prodesignUp=new GraduationDesign();
		prodesignUp.setDesignId(request.getParameter("designId"));
		prodesignUp.setDesignName(request.getParameter("designName6").trim());
		prodesignUp.setProName(request.getParameter("proName6").trim());
		prodesignUp.setDesignDate(request.getParameter("designDate6").trim());
		//System.out.println(request.getParameter("designName6"));
		prodesignUp.setSymajor(request.getParameter("symajor6").trim());
		prodesignUp.setNanyi(request.getParameter("nanyi6").trim());
		prodesignUp.setType(request.getParameter("type6").trim());
		prodesignUp.setScoure(request.getParameter("scoure6").trim());
		int count;
		try {
			count=designDao.prodesignUpdate(dbUtil.getCon(), prodesignUp, request.getParameter("designId6"));
			if(count>0){
				request.setAttribute("success", "�޸ĳɹ�");
				System.out.println("success");
			}else{
				request.setAttribute("error", "�޸�ʧ��");
				//System.out.println("jinru");
			}
			request.getRequestDispatcher("Profession/design/design_show.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	
}
