package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.SignUpDao;
import com.mcg.cn.model.SignUp;
import com.mcg.cn.util.DbUtil;

public class proselectSignIdeaServlet extends HttpServlet{

	/**
	 * ��ʦ�鿴ѧ���Ĳ�ǩ����
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	SignUpDao signupDao=new SignUpDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		SignUp stuSignUp=new SignUp();
		
		request.setCharacterEncoding("utf-8");
		
		try {
			SignUp stuSignUp1=signupDao.stuSignUpselect(dbUtil.getCon(), request.getParameter("stuName13"));
			request.setAttribute("stuSignUp", stuSignUp1);
			request.getRequestDispatcher("Profession/SignUp/proselectSignIdea.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/**
		 * 
		 * */

		/*try {
			proSignups=signupDao.proSignUpshow(dbUtil.getCon(),request.getParameter("major0"), request.getParameter("stuName13"));
			request.setAttribute("proSignups", proSignups);
			request.getRequestDispatcher("Profession/SignUp/proselectSignIdea.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	

	
}
