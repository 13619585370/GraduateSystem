package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.GraduteDao;
import com.mcg.cn.util.DbUtil;

public class graduteDeleteServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	GraduteDao graduteDao=new GraduteDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int count;
		try {
			count=graduteDao.GraduteDelete(dbUtil.getCon(), request.getParameter("stuId2"));
			//System.out.println(request.getParameter("id"));
			System.out.println(request.getParameter("stuId2"));
			request.getRequestDispatcher("admin/graInfo/graInfoMan.jsp").forward(request, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
}
