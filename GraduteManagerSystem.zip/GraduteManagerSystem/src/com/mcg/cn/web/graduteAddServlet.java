package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.GraduteDao;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.util.DbUtil;

public class graduteAddServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	GraduteDao graduteDao=new GraduteDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Gradute gradute=new Gradute();
		
		 /**
	     * ����ѧ����Ϣ
	     * 
	     * */
	    //gradute.setStuNum("20142266");
	    request.setCharacterEncoding("utf-8");
	    gradute.setStuNum(request.getParameter("stuNum"));
	    gradute.setStuName(request.getParameter("stuName"));
	    gradute.setPassword(request.getParameter("password"));
	    gradute.setSex(request.getParameter("sex"));
	    gradute.setMajor(request.getParameter("major"));
	    gradute.setGradeClass(request.getParameter("gradeClass"));
	    gradute.setAddress(request.getParameter("address"));
	    gradute.setPhoneNum(request.getParameter("phoneNum"));
	    gradute.setPoliticsSta(request.getParameter("politicsSta"));
	    gradute.setStage(request.getParameter("stage"));
	    
	    int count;
	    try {
			count=graduteDao.GraduteAdd(dbUtil.getCon(), gradute);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("gradute").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	

	
}
