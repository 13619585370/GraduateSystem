package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.stuDesign;
import com.mcg.cn.util.DbUtil;

public class prodesignDisDelete extends HttpServlet{

	/**
	 * ɾ����ͬ���ѧ��
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");
		
		stuDesign prodesigndisDele=new stuDesign();
		
		int count;
		try {
			count=designDao.prodesignDisDelete(dbUtil.getCon(), request.getParameter("stuName8"));
			if(count>0){
				request.setAttribute("success", "ɾ���ɹ�");
				System.out.println("success");
			}else{
				request.setAttribute("error", "�޸�ʧ��");
				//System.out.println("jinru");
			}
			request.getRequestDispatcher("Profession/design/prodesignDisagree.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	

}
