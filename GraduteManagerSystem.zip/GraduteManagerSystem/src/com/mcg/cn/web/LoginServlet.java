package com.mcg.cn.web;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mcg.cn.dao.UserDao;
import com.mcg.cn.model.Admin;
import com.mcg.cn.model.Department;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.model.Profession;
import com.mcg.cn.util.DbUtil;

public class LoginServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
    DbUtil dbUtil=new DbUtil();
    UserDao userDao=new UserDao();
    
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		super.doGet(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    /**
	     * У����֤��
	     * */
		request.setCharacterEncoding("utf-8");
		String c_checkcode=request.getParameter("checkcode");
		//System.out.println(request.getParameter("checkcode"));
		String s_checkcode=(String)request.getSession().getAttribute("checkcode");
		if(c_checkcode!=null&&s_checkcode!=null&&c_checkcode.equals("s_checkcode")){
			System.out.println("��֤��������ȷ");
		}else{
			System.out.println("��֤���������");
		}
		
		
	    String userName=request.getParameter("userName");
	    String password=request.getParameter("password");
	    request.setAttribute("userName", userName);
	    request.setAttribute("password", password);
	    String userType=request.getParameter("userType");
	    
	    Connection conn=null;
	    
	    try{
	    	conn=dbUtil.getCon();
	    	//System.out.println(userType);
	    	if("admin".equals(userType)){
	    		Admin admin =new Admin(userName,password);
	    		Admin currentAdmin= userDao.Login(conn, admin);
	    		if(currentAdmin==null){
	    			request.setAttribute("error", "�û������������");
	    			request.getRequestDispatcher("login.jsp").forward(request, response);
	    		}else{
	    			HttpSession session=request.getSession();
	    			session.setAttribute("currentUser", currentAdmin);
	    			response.sendRedirect("admin/admin.jsp");
	    		}
	    	}else if("profession".equals(userType)){
    			Profession profession=new Profession(userName,password);
    			Profession currentProfession=userDao.Login(conn, profession);
    			if(currentProfession==null){
    				request.setAttribute("error", "�û������������");
    				//�ͻ�����ת
    				request.getRequestDispatcher("login.jsp").forward(request, response);
    			}else{
    				HttpSession session=request.getSession();
    				session.setAttribute("currentUser", currentProfession);
    				//��������ת
    				response.sendRedirect("Profession/profession.jsp");
    			}
    		}else if("gradute".equals(userType)){
    			  Gradute gradute=new Gradute(userName,password);
    			  Gradute currentGradute=userDao.Login(conn, gradute);
    			  if(currentGradute==null){
    				  request.setAttribute("error", "�û������������");
    				  request.getRequestDispatcher("login.jsp").forward(request, response);
    			  }else{
    				  HttpSession session=request.getSession();
    				  session.setAttribute("currentUser", currentGradute);
    				  response.sendRedirect("Gradute/gradute.jsp");
    			  }
    		}else if("department".equals(userType)){
    			Department department=new Department(userName,password);
    			Department currentDepartment=userDao.Login(conn, department);
    			if(currentDepartment==null){
    				request.setAttribute("error", "�û������������");
    				request.getRequestDispatcher("login.jsp").forward(request, response);
    			}else{
    				HttpSession session=request.getSession();
    				session.setAttribute("currentUser", currentDepartment);
    				response.sendRedirect("Department/department.jsp");
    			}
    		}
	    	
	    }catch(Exception e){
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		dbUtil.CloseCon(conn);
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
	    
		
	}
    
    
}
