package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.GraduteDao;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.util.DbUtil;

public class graduteUpdateServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	DbUtil dbUtil=new DbUtil();
	GraduteDao graduteDao=new GraduteDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(request, response);
		
		 /*
	     * �޸�
	     * 
	     * */
	    Gradute gradute=new Gradute();
	    request.setCharacterEncoding("utf-8");
	    gradute.setStuNum(request.getParameter("stuNum1"));
	    gradute.setStuName(request.getParameter("stuName1"));
	    gradute.setPassword(request.getParameter("password1"));
	    gradute.setSex(request.getParameter("sex1"));
	    gradute.setMajor(request.getParameter("major1"));
	    gradute.setGradeClass(request.getParameter("gradeClass1"));
	    gradute.setAddress(request.getParameter("address1"));
	    gradute.setPhoneNum(request.getParameter("phoneNum1"));
	    gradute.setPoliticsSta(request.getParameter("politicsSta1"));
	    gradute.setStage(request.getParameter("stage1"));
	    
	    int count;
	    try {
	    	
	    	//System.out.println(request.getParameter("stuNum1"));
			count=graduteDao.GraduteModify(dbUtil.getCon(), gradute,request.getParameter("stuNum1"));
			if(count>0){
				request.setAttribute("success", "�޸ĳɹ�");
				System.out.println("success");
			}else{
				request.setAttribute("error", "�޸�ʧ��");
				System.out.println("jinru");
			}
			request.getRequestDispatcher("admin/graInfo/graInfoMan.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
}
