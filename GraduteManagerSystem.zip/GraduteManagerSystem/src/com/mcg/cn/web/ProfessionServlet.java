package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.professionDao;
import com.mcg.cn.model.Profession;
import com.mcg.cn.util.DbUtil;

public class ProfessionServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	professionDao professiondao=new professionDao();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 List<Profession> professions=null;
		 Profession profession=new Profession();
		 /**
		  * ��ѯ��ʦ��Ϣ
		  * 
		  * */
		try{
			professions=professiondao.proshow(dbUtil.getCon());
			request.setAttribute("profession", professions);
			request.getRequestDispatcher("admin/proInfo/proInfoMan.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		/**
		 * ���ӽ�ʦ
		 * 
		 * **/
		request.setCharacterEncoding("utf-8");
		profession.setProNum(request.getParameter("proNum"));
		profession.setProName(request.getParameter("proName"));
		profession.setPassword(request.getParameter("password"));
		profession.setSex(request.getParameter("sex"));
		
		int count;
		try {
			count=professiondao.ProfessionAdd(dbUtil.getCon(), profession);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
