package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.deptDao;
import com.mcg.cn.model.Department;
import com.mcg.cn.util.DbUtil;

public class DepartmentServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DbUtil dbUtil=new DbUtil();
	deptDao deptdao=new deptDao();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     
		List<Department> depts=null;
		Department department=new Department();
		/**
		 * ��ѯ���ŵ���Ϣ
		 * 
		 * */
		try {
			depts=deptdao.deptshow(dbUtil.getCon());
			request.setAttribute("dept", depts);
			request.getRequestDispatcher("admin/deptInfo/deptInfoMan.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/**
		 * ���Ӳ���
		 * 
		 * */
		request.setCharacterEncoding("utf-8");
		department.setDeptNum(request.getParameter("deptNum"));
		department.setDeptName(request.getParameter("deptName"));
		department.setPassword(request.getParameter("password"));
		
		int count;
		try {
			count=deptdao.departmentAdd(dbUtil.getCon(), department);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("admin/deptInfo/deptAdd.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
