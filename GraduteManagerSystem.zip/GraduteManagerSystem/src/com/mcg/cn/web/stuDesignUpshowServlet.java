package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class stuDesignUpshowServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	/**
	 * Ϊ�޸���ʦ�����ı�ҵ��������ѯ
	 * */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		request.setCharacterEncoding("utf-8");
		GraduationDesign prodesign=null;
		String num2=request.getParameter("designName4").trim();
		System.out.println(num2);
		try {
			prodesign=designDao.proDesignUpShow(dbUtil.getCon(),request.getParameter("designName4").trim());
			request.setAttribute("prodesign", prodesign);
			
			request.getRequestDispatcher("Profession/design/prodesignChange.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	
}
