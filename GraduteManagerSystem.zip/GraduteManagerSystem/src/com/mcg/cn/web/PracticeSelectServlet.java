package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.PracticeDao;
import com.mcg.cn.model.Practice;
import com.mcg.cn.util.DbUtil;

public class PracticeSelectServlet extends HttpServlet{

	/**
	 * ����ѧ��ʵϰ�ϴ�����Ϣ
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	PracticeDao practiceDao=new PracticeDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Practice> practices=null;
		request.setCharacterEncoding("utf-8");
		System.out.println(request.getParameter("major21"));
		try {
			practices=practiceDao.practiceShow(dbUtil.getCon(), request.getParameter("major21"));
			request.setAttribute("practices", practices);
			request.getRequestDispatcher("Profession/Practice/practice_select1.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
}
