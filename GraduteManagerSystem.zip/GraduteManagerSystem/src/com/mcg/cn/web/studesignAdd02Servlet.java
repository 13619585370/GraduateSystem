package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.stuDesignSelectDao;
import com.mcg.cn.model.stuDesign;
import com.mcg.cn.util.DbUtil;

public class studesignAdd02Servlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	stuDesignSelectDao studesignSelect =new stuDesignSelectDao();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		request.setCharacterEncoding("utf-8");
		stuDesign studesign=new stuDesign();
		System.out.println(request.getParameter("designName18"));
		studesign.setDesignName(request.getParameter("designName18"));
		studesign.setSymajor(request.getParameter("symajor18"));
		studesign.setNanyi(request.getParameter("nanyi18"));
		studesign.setType(request.getParameter("type18"));
		studesign.setScoure(request.getParameter("scoure18"));
		studesign.setProName(request.getParameter("proName18"));
		studesign.setDesignDate(request.getParameter("designDate18"));
		
		int count;
		try {
			count=studesignSelect.stuDesignAdd(dbUtil.getCon(), studesign);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("Gradute/design/gra_design04.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
