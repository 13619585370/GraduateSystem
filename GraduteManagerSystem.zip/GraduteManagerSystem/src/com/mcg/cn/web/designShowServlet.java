package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class designShowServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		/*
		 * ��ѯ��ҵ�����Ŀ��Ϣ
		 * 
		 * **/
		
		List<GraduationDesign> gradesigns=null;
		request.setCharacterEncoding("utf-8");
		try {
			//System.out.println(request.getParameter("proName1"));
			gradesigns=designDao.designshow(dbUtil.getCon(), request.getParameter("proName1"));
			request.setAttribute("gradesign", gradesigns);
			request.getRequestDispatcher("Profession/design/design_show.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	
}
