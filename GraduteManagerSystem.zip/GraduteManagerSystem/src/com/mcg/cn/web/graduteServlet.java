package com.mcg.cn.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.GraduteDao;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.util.DbUtil;

public class graduteServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	GraduteDao graduteDao=new GraduteDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
		/***
		 * ��ѯѧ����Ϣ
		 */
		Gradute gradute=new Gradute();
	    List<Gradute> gradutes=null;
	    
	    try{
	    	gradutes=graduteDao.graduteshow(dbUtil.getCon());
	    	request.setAttribute("gradute", gradutes);
	    	request.getRequestDispatcher("admin/graInfo/graInfoMan.jsp").forward(request, response);
	    }catch(Exception e){
	    	e.printStackTrace();
	    }

	    
	    
	    /**
	     * Ϊ�޸Ķ���ѯ
	     * 
	     * */
	
	    
	    
	    
	    /**
	     * �޸�����
	     * */
		
	    
	    
	    
	}
	
	
	
	

}
