package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mcg.cn.dao.SignUpDao;
import com.mcg.cn.model.SignUp;
import com.mcg.cn.util.DbUtil;

public class stuSignUpshowServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	SignUpDao signupDao=new SignUpDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		SignUp stuSignUp=null;
		request.setCharacterEncoding("utf-8");
		  // HttpSession session=request.getSession();
		  // String userName=request.getParameter("userName");
		    //String password=request.getParameter("password");
		   // session.setAttribute("userName", userName);
		try {
			stuSignUp=signupDao.stuSignUpselect(dbUtil.getCon(), request.getParameter("stuName11").trim());
			request.setAttribute("stuSignUp", stuSignUp);
			request.getRequestDispatcher("Gradute/Signup/signup_show1.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	

}
