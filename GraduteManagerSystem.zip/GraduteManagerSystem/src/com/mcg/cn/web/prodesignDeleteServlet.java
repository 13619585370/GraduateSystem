package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class prodesignDeleteServlet extends HttpServlet{

	/**
	 * ɾ����ʦ���� �ı�ҵ�����Ŀ
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	DesignDao designDao=new DesignDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		GraduationDesign prodesignDele=new GraduationDesign();
		
		request.setCharacterEncoding("utf-8");
		int count;
		try {
			count=designDao.prodesignDelete(dbUtil.getCon(), request.getParameter("designId7"));
			if(count>0){
				request.setAttribute("success", "ɾ���ɹ�");
				System.out.println("success");
			}else{
				request.setAttribute("error", "�޸�ʧ��");
				//System.out.println("jinru");
			}
			request.getRequestDispatcher("Profession/design/prodesignDelete1.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
}
