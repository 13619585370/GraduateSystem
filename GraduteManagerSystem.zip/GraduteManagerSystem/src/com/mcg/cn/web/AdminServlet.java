package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.AdminDao;
import com.mcg.cn.model.Admin;
import com.mcg.cn.util.DbUtil;

public class AdminServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	AdminDao adminDao=new AdminDao();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Admin admin=null;
		//String userType=request.getParameter("userType");
		 String userName=request.getParameter("userName");
		 System.out.println(request.getParameter("userName"));
		try {
			admin=adminDao.adminShow(dbUtil.getCon(),"���ٿ�");
			request.setAttribute("admin", admin);  
		    request.getRequestDispatcher("admin/info_01.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(admin.toString());
	    
		
	}
	
	

}
