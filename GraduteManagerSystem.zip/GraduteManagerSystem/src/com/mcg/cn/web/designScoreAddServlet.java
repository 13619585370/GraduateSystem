package com.mcg.cn.web;

import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.DesignDao;
import com.mcg.cn.dao.ScoreDao;
import com.mcg.cn.model.GraduationDesign;
import com.mcg.cn.util.DbUtil;

public class designScoreAddServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	ScoreDao scoreDao=new ScoreDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	     doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		/**
		 * ��ʦ���ӱ�ҵ�����Ŀ
		 * 
		 * **/
		GraduationDesign progradutaDesign=new GraduationDesign();
		request.setCharacterEncoding("utf-8");
		
		progradutaDesign.setDesignName(request.getParameter("designName14"));
		progradutaDesign.setProName(request.getParameter("proName14"));
		//progradutaDesign.setDesignDate(request.getParameter("designDate2").trim());
		progradutaDesign.setSymajor(request.getParameter("symajor14"));
		progradutaDesign.setStuName(request.getParameter("stuName14"));
		progradutaDesign.setNanyi(request.getParameter("nanyi14"));
		progradutaDesign.setType(request.getParameter("type14"));
		progradutaDesign.setScoure(request.getParameter("scoure14"));
		System.out.println(request.getParameter("bsScore"));
		
		progradutaDesign.setBsScore(request.getParameter("bsScore").trim());
		progradutaDesign.setLwScore(request.getParameter("lwScore".trim()));
		progradutaDesign.setSumScore(request.getParameter("sumScore").trim());
		
		int count;
		try {
			count=scoreDao.proDesginAdd(dbUtil.getCon(), progradutaDesign);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("Profession/stuScore/stuScore_select.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	

	
}
