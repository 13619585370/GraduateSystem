package com.mcg.cn.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.SignUpDao;
import com.mcg.cn.model.SignUp;
import com.mcg.cn.util.DbUtil;

public class SignUpAddServlet extends HttpServlet{

	/**
	 * ѧ������ǩ����Ϣ
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	SignUpDao signupDao=new SignUpDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
         SignUp signUp=new SignUp();
         request.setCharacterEncoding("utf-8");
         
         signUp.setStuNum(request.getParameter("stuNum9").trim());
         signUp.setStuName(request.getParameter("stuName9").trim());
         signUp.setMajor(request.getParameter("major9").trim());
         signUp.setGradeClass(request.getParameter("gradeClass9").trim());
         signUp.setSex(request.getParameter("sex9").trim());
         signUp.setPhoneNum(request.getParameter("phoneNum9").trim());
         signUp.setAddress(request.getParameter("address9").trim());
         signUp.setSignDate(request.getParameter("signDate9"));
         signUp.setIdea(request.getParameter("idea9"));
         signUp.setResignDate(request.getParameter("resignDate9"));
         
         int count;
         try {
			count=signupDao.signupAdd(dbUtil.getCon(), signUp);
			if(count>0){
				request.setAttribute("success", "���ӳɹ�");
			}else{
				request.setAttribute("error", "����ʧ��");
			}
			request.getRequestDispatcher("Gradute/Signup/signup_0201.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
}
