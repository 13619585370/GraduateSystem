package com.mcg.cn.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.stuDesignDao;
import com.mcg.cn.model.stuDesign;
import com.mcg.cn.util.DbUtil;

public class stuDesignServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	stuDesignDao studesignDao=new stuDesignDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/**
		 * ��ʾѧ��ѡ�����
		 * */
		List<stuDesign> studesigns=null;
		request.setCharacterEncoding("utf-8");
		
		try {
			studesigns=studesignDao.stuDesignShow(dbUtil.getCon(), request.getParameter("proName3"));
			request.setAttribute("studesign", studesigns);
			request.getRequestDispatcher("Profession/design/design_shenhe.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	

	
}
