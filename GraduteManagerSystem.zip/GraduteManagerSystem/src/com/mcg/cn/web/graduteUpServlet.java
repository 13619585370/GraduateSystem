package com.mcg.cn.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.dao.GraduteDao;
import com.mcg.cn.model.Gradute;
import com.mcg.cn.util.DbUtil;

public class graduteUpServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil=new DbUtil();
	GraduteDao graduteDao=new GraduteDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		/**
		 * Ϊ�޸�ѧ����Ϣ����ѯ
		 * */
		request.setCharacterEncoding("utf-8");
		    Gradute graduteUp=null;
		    try {
		    	System.out.println(request.getParameter("id"));
		    	String num=request.getParameter("stuNum");
				graduteUp=graduteDao.graduteshowupdate(dbUtil.getCon(), num);
				request.setAttribute("graduteUp", graduteUp);
				//PrintWriter out = response.getWriter();
				//out.println("true");
				request.getRequestDispatcher("admin/graInfo/graChange.jsp").forward(request, response);
				//response.sendRedirect("admin/graInfo/graChange.jsp");
				System.out.println("��ת");
		    } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		   
	}

	
}
