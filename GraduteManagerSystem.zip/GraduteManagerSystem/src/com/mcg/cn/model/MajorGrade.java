package com.mcg.cn.model;

public class MajorGrade {
      private String majorgraId;
      private String stuName;
      private String cLanguage;
      private String java;
      private String softEngin;
      private String sqlServer;
      private String computerOrg;
      private String computerNet;
      private String linux;
      private String oracle;
      
	public MajorGrade() {
		super();
	}

	public MajorGrade(String majorgraId, String stuName, String cLanguage, String java, String softEngin,
			String sqlServer, String computerOrg, String computerNet, String linux, String oracle) {
		super();
		this.majorgraId = majorgraId;
		this.stuName = stuName;
		this.cLanguage = cLanguage;
		this.java = java;
		this.softEngin = softEngin;
		this.sqlServer = sqlServer;
		this.computerOrg = computerOrg;
		this.computerNet = computerNet;
		this.linux = linux;
		this.oracle = oracle;
	}

	public String getMajorgraId() {
		return majorgraId;
	}

	public void setMajorgraId(String majorgraId) {
		this.majorgraId = majorgraId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getcLanguage() {
		return cLanguage;
	}

	public void setcLanguage(String cLanguage) {
		this.cLanguage = cLanguage;
	}

	public String getJava() {
		return java;
	}

	public void setJava(String java) {
		this.java = java;
	}

	public String getSoftEngin() {
		return softEngin;
	}

	public void setSoftEngin(String softEngin) {
		this.softEngin = softEngin;
	}

	public String getSqlServer() {
		return sqlServer;
	}

	public void setSqlServer(String sqlServer) {
		this.sqlServer = sqlServer;
	}

	public String getComputerOrg() {
		return computerOrg;
	}

	public void setComputerOrg(String computerOrg) {
		this.computerOrg = computerOrg;
	}

	public String getComputerNet() {
		return computerNet;
	}

	public void setComputerNet(String computerNet) {
		this.computerNet = computerNet;
	}

	public String getLinux() {
		return linux;
	}

	public void setLinux(String linux) {
		this.linux = linux;
	}

	public String getOracle() {
		return oracle;
	}

	public void setOracle(String oracle) {
		this.oracle = oracle;
	}
	
	
      
      
      
}
