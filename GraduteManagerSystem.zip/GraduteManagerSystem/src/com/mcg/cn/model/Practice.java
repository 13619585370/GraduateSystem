package com.mcg.cn.model;

public class Practice {

	private String practiceId;
	private String stuNum;
	private String stuName;
	private String major;
	private String gradeClass;
	private String praAddress;
	private String startDate;
	private String endDate;
	private String praContent;
	private String prove;
	
	public Practice() {
		super();
	}

	public Practice(String practiceId, String stuNum, String stuName, String major, String gradeClass,
			String praAddress, String startDate, String endDate, String praContent, String prove) {
		super();
		this.practiceId = practiceId;
		this.stuNum = stuNum;
		this.stuName = stuName;
		this.major = major;
		this.gradeClass = gradeClass;
		this.praAddress = praAddress;
		this.startDate = startDate;
		this.endDate = endDate;
		this.praContent = praContent;
		this.prove = prove;
	}

	public String getPracticeId() {
		return practiceId;
	}

	public void setPracticeId(String practiceId) {
		this.practiceId = practiceId;
	}

	public String getStuNum() {
		return stuNum;
	}

	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getGradeClass() {
		return gradeClass;
	}

	public void setGradeClass(String gradeClass) {
		this.gradeClass = gradeClass;
	}

	public String getPraAddress() {
		return praAddress;
	}

	public void setPraAddress(String praAddress) {
		this.praAddress = praAddress;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPraContent() {
		return praContent;
	}

	public void setPraContent(String praContent) {
		this.praContent = praContent;
	}

	public String getProve() {
		return prove;
	}

	public void setProve(String prove) {
		this.prove = prove;
	}
	
	
}
