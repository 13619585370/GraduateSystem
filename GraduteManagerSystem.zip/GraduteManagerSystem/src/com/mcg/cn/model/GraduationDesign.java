package com.mcg.cn.model;


public class GraduationDesign {
	private String DesignId;
	private String DesignName;
	private String stuName;
	private String proName;
	private String DesignDate;
	private String symajor;
	private String nanyi;
	private String require;
	private String type;
	private String scoure;
	private String bsScore;
	private String lwScore;
	private String sumScore;
	
	public GraduationDesign() {
		super();
	}

   

    



	public GraduationDesign(String designId, String designName, String stuName, String proName, String designDate,
			String symajor, String nanyi, String require, String type, String scoure, String bsScore, String lwScore,
			String sumScore) {
		super();
		DesignId = designId;
		DesignName = designName;
		this.stuName = stuName;
		this.proName = proName;
		DesignDate = designDate;
		this.symajor = symajor;
		this.nanyi = nanyi;
		this.require = require;
		this.type = type;
		this.scoure = scoure;
		this.bsScore = bsScore;
		this.lwScore = lwScore;
		this.sumScore = sumScore;
	}







	public String getDesignId() {
		return DesignId;
	}

	public void setDesignId(String designId) {
		DesignId = designId;
	}

	public String getDesignName() {
		return DesignName;
	}

	public void setDesignName(String designName) {
		DesignName = designName;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getDesignDate() {
		return DesignDate;
	}

	public void setDesignDate(String designDate) {
		DesignDate = designDate;
	}



	public String getSymajor() {
		return symajor;
	}



	public void setSymajor(String symajor) {
		this.symajor = symajor;
	}



	public String getNanyi() {
		return nanyi;
	}



	public void setNanyi(String nanyi) {
		this.nanyi = nanyi;
	}



	public String getRequire() {
		return require;
	}



	public void setRequire(String require) {
		this.require = require;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public String getScoure() {
		return scoure;
	}



	public void setScoure(String scoure) {
		this.scoure = scoure;
	}







	public String getBsScore() {
		return bsScore;
	}







	public void setBsScore(String bsScore) {
		this.bsScore = bsScore;
	}







	public String getLwScore() {
		return lwScore;
	}







	public void setLwScore(String lwScore) {
		this.lwScore = lwScore;
	}







	public String getSumScore() {
		return sumScore;
	}







	public void setSumScore(String sumScore) {
		this.sumScore = sumScore;
	}
	
	
    
	
}
