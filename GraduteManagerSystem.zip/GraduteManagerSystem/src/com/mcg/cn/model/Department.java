package com.mcg.cn.model;

public class Department {
    private int deptId;
    private String deptNum;
    private String deptName;
    private String password;
    
    
	public Department() {
		super();
	}


	public Department(String deptName, String password) {
		super();
		this.deptName = deptName;
		this.password = password;
	}


	public int getDeptId() {
		return deptId;
	}


	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}


	public String getDeptNum() {
		return deptNum;
	}


	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}


	public String getDeptName() {
		return deptName;
	}


	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
    
    
	
}
