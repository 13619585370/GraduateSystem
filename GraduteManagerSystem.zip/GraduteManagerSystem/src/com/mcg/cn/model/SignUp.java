package com.mcg.cn.model;

public class SignUp {
	private String signupId;
	private String stuNum;
	private String stuName;
	private String major;
	private String gradeClass;
	private String sex;
	private String phoneNum;
	private String address;
	private String signDate;
	private String idea;
	private String resignDate;
	
	public SignUp() {
		super();
	}

	public SignUp(String signupId, String stuNum, String stuName, String major, String gradeClass, String sex,
			String phoneNum, String address, String signDate, String idea, String resignDate) {
		super();
		this.signupId = signupId;
		this.stuNum = stuNum;
		this.stuName = stuName;
		this.major = major;
		this.gradeClass = gradeClass;
		this.sex = sex;
		this.phoneNum = phoneNum;
		this.address = address;
		this.signDate = signDate;
		this.idea = idea;
		this.resignDate = resignDate;
	}

	public String getSignupId() {
		return signupId;
	}

	public void setSignupId(String signupId) {
		this.signupId = signupId;
	}

	public String getStuNum() {
		return stuNum;
	}

	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getGradeClass() {
		return gradeClass;
	}

	public void setGradeClass(String gradeClass) {
		this.gradeClass = gradeClass;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSignDate() {
		return signDate;
	}

	public void setSignDate(String signDate) {
		this.signDate = signDate;
	}

	public String getIdea() {
		return idea;
	}

	public void setIdea(String idea) {
		this.idea = idea;
	}

	public String getResignDate() {
		return resignDate;
	}

	public void setResignDate(String resignDate) {
		this.resignDate = resignDate;
	}
	
	
	

}
