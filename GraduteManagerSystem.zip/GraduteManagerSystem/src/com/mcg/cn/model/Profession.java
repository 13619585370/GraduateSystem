package com.mcg.cn.model;

public class Profession {
    private int proId;
    private String proNum;
    private String proName;
    private String password;
    private String sex;
    
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Profession() {
		super();
	}

	public Profession(String proName, String password) {
		super();
		this.proName = proName;
		this.password = password;
	}
	
	

	public Profession(int proId, String proNum, String proName, String password, String sex) {
		super();
		this.proId = proId;
		this.proNum = proNum;
		this.proName = proName;
		this.password = password;
		this.sex = sex;
	}

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getProNum() {
		return proNum;
	}

	public void setProNum(String proNum) {
		this.proNum = proNum;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
    
    
}
