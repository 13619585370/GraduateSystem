package com.mcg.cn.model;

public class stuDesign {

	private int DesignId;
	private String DesignName;
	private String stuName;
	private String proName;
	private String DesignDate;
	private String symajor;
	private String nanyi;
	private String type;
	private String scoure;
	
	public stuDesign() {
		super();
	}

	

	public stuDesign(int designId, String designName, String stuName, String proName, String designDate, String symajor,
			String nanyi, String type, String scoure) {
		super();
		DesignId = designId;
		DesignName = designName;
		this.stuName = stuName;
		this.proName = proName;
		DesignDate = designDate;
		this.symajor = symajor;
		this.nanyi = nanyi;
		this.type = type;
		this.scoure = scoure;
	}



	public int getDesignId() {
		return DesignId;
	}

	public void setDesignId(int designId) {
		DesignId = designId;
	}

	public String getDesignName() {
		return DesignName;
	}

	public void setDesignName(String designName) {
		DesignName = designName;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getDesignDate() {
		return DesignDate;
	}

	public void setDesignDate(String designDate) {
		DesignDate = designDate;
	}



	public String getSymajor() {
		return symajor;
	}



	public void setSymajor(String symajor) {
		this.symajor = symajor;
	}



	public String getNanyi() {
		return nanyi;
	}



	public void setNanyi(String nanyi) {
		this.nanyi = nanyi;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public String getScoure() {
		return scoure;
	}



	public void setScoure(String scoure) {
		this.scoure = scoure;
	}
	
	
}
