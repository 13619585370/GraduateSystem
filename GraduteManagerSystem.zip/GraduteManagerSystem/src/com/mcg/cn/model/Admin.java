package com.mcg.cn.model;

public class Admin {
	
	private int adminId;
	private String adminNum;
	private String adminName;
	private String password;
	
	public Admin() {
		super();
	}

	
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminNum=" + adminNum + ", adminName=" + adminName + ", password="
				+ password + "]";
	}


	public Admin(String adminName, String password) {
		super();
		this.adminName = adminName;
		this.password = password;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminNum() {
		return adminNum;
	}

	public void setAdminNum(String adminNum) {
		this.adminNum = adminNum;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
