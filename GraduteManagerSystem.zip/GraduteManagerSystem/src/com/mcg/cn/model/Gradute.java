package com.mcg.cn.model;

public class Gradute {
    private int stuId;
    private String stuNum;
    private String stuName;
    private String password;
    private String sex;
    private String major;
    private String gradeClass;
    private String address;
    private String phoneNum;
    private String politicsSta;
    private String stage;
    
    
	public Gradute() {
		super();
	}


	public Gradute(String stuName, String password) {
		super();
		this.stuName = stuName;
		this.password = password;
	}


	
	
	@Override
	public String toString() {
		return "Gradute [stuId=" + stuId + ", stuNum=" + stuNum + ", stuName=" + stuName + ", password=" + password
				+ ", sex=" + sex + ", major=" + major + ", gradeClass=" + gradeClass + ", address=" + address
				+ ", phoneNum=" + phoneNum + ", politicsSta=" + politicsSta + ", stage=" + stage + "]";
	}


	public Gradute(int stuId, String stuNum, String stuName, String password, String sex, String major,
			String gradeClass, String address, String phoneNum, String politicsSta, String stage) {
		super();
		this.stuId = stuId;
		this.stuNum = stuNum;
		this.stuName = stuName;
		this.password = password;
		this.sex = sex;
		this.major = major;
		this.gradeClass = gradeClass;
		this.address = address;
		this.phoneNum = phoneNum;
		this.politicsSta = politicsSta;
		this.stage = stage;
	}


	public int getStuId() {
		return stuId;
	}


	public void setStuId(int stuId) {
		this.stuId = stuId;
	}


	public String getStuNum() {
		return stuNum;
	}


	public void setStuNum(String stuNum) {
		this.stuNum = stuNum;
	}


	public String getStuName() {
		return stuName;
	}


	public void setStuName(String stuName) {
		this.stuName = stuName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public String getMajor() {
		return major;
	}


	public void setMajor(String major) {
		this.major = major;
	}


	public String getGradeClass() {
		return gradeClass;
	}


	public void setGradeClass(String gradeClass) {
		this.gradeClass = gradeClass;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhoneNum() {
		return phoneNum;
	}


	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}


	public String getPoliticsSta() {
		return politicsSta;
	}


	public void setPoliticsSta(String politicsSta) {
		this.politicsSta = politicsSta;
	}


	public String getStage() {
		return stage;
	}


	public void setStage(String stage) {
		this.stage = stage;
	}

    
}
