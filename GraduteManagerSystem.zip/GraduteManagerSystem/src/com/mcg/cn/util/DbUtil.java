package com.mcg.cn.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {

	private String dbUrl="jdbc:sqlserver://localhost:1433;DatabaseName=GraduteManagerSystem";
	private String dbName="sa";
	private String dbPasseword="20142266";
	
	private String jdbcName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
	
	/**
	 * ���ݿ������
	 * @return
	 * @throws Exceptoin
	 * */
	
	public Connection getCon() throws Exception{
		Class.forName(jdbcName);
		Connection conn=DriverManager.getConnection(dbUrl, dbName, dbPasseword);
		return conn;
	}
	
	/**
	 * ���ݿ�ر�
	 * @param
	 * @throws Exception
	 * 
	 * */
	
	public void CloseCon(Connection conn) throws Exception{
		if(conn!=null){
			conn.close();
		}
	}
	
	/**
	 * ������
	 * 
	 * */
	
	public static void main(String[] args){
		DbUtil dbUtil=new DbUtil();
		try{
			dbUtil.getCon();
			System.out.println("���ݿ����ӳɹ�");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}
