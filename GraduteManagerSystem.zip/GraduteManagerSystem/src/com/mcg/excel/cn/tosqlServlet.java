package com.mcg.excel.cn;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcg.cn.model.Gradute;

public class tosqlServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		into in=new into();
		excel ex=new excel();
		
		String path=new String(request.getParameter("excel").getBytes(),"utf-8");
		//String path=new String(‪"");
		System.out.println(path);
		File file=new File(path);
		
		List ls=ex.addCustomerAssign(file);
		Iterator<Gradute> iter=ls.iterator();
		
		while(iter.hasNext()){
			Gradute gra=new Gradute();
			if(in.insertexcel(gra)){
				System.out.println("成功");
			}else{
				System.out.println("失败");
			}
		}
		
	}
	
	

	
}
