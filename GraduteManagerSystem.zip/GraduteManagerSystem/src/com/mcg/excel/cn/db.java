package com.mcg.excel.cn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class db {

	public Connection conn=null;
	public ResultSet rs=null;
	public PreparedStatement pstmt=null;
	
	private String strUrl="jdbc:sqlserver://localhost:1433;DatabaseName=GraduteManagerSystem";
	private String strUser="sa";
	private String strPassword="20142266";
	
	private String jdbcName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
	
	/**
	 * ���ݿ������
	 * @return
	 * @throws Exceptoin
	 * */
	
	public Connection getCon() throws Exception{
		Class.forName(jdbcName);
		Connection conn=DriverManager.getConnection(strUrl, strUser, strPassword);
		return conn;
	}
	
	/**
	 * ���ݿ�ر�
	 * @param
	 * @throws Exception
	 * 
	 * */
	
	public void CloseCon(Connection conn) throws Exception{
		if(conn!=null){
			conn.close();
		}
	}
	
	/**
	 * ������
	 * 
	 * */
	
	public static void main(String[] args){
		db dbUtil=new db();
		try{
			dbUtil.getCon();
			System.out.println("���ݿ����ӳɹ�");
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	public ResultSet exceuteQuery(String sql) throws Exception{
		Statement stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		return rs;
	}
	
	public PreparedStatement dosql(String sql) throws Exception{
		pstmt=conn.prepareStatement(sql);
		return pstmt;
	}
}
