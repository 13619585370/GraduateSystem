package com.mcg.excel.cn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.mcg.cn.model.Gradute;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class excel {
	public List<Gradute> addCustomerAssign(File file) throws FileNotFoundException{
		List ls=new ArrayList();
		jxl.Workbook rwb=null;
		
			
			try {
				InputStream is=new FileInputStream(file);
				rwb=Workbook.getWorkbook(is);
				Sheet rs=rwb.getSheet(0);
				int rsRows=rs.getRows();
				for(int i=1;i<rsRows;i++){
					String cell1=rs.getCell(0, i).getContents()+"";
					String cell2=rs.getCell(1, i).getContents()+"";
					String cell3=rs.getCell(2, i).getContents()+"";
					String cell4=rs.getCell(3, i).getContents()+"";
					String cell5=rs.getCell(4, i).getContents()+"";
					String cell6=rs.getCell(5, i).getContents()+"";
					String cell7=rs.getCell(6, i).getContents()+"";
					String cell8=rs.getCell(7, i).getContents()+"";
					String cell9=rs.getCell(8, i).getContents()+"";
					String cell10=rs.getCell(9, i).getContents()+"";
					
					if(cell1!=null&&!cell1.equals("")&&cell2!=null&&!cell3.equals("")&&cell4!=null&&!cell5.equals("")&&cell6!=null&&!cell7.equals("")&&cell8!=null&&!cell9.equals("")&&cell10!=null&&!cell10.equals("")){
						Gradute gra=new Gradute();
						gra.setStuNum(rs.getCell(0, i).getContents());
						gra.setStuName(rs.getCell(1, i).getContents());
						gra.setPassword(rs.getCell(2, i).getContents());
						gra.setSex(rs.getCell(3, i).getContents());
						gra.setMajor(rs.getCell(4, i).getContents());
						gra.setGradeClass(rs.getCell(5, i).getContents());
						gra.setAddress(rs.getCell(6, i).getContents());
						gra.setPhoneNum(rs.getCell(7, i).getContents());
						gra.setPoliticsSta(rs.getCell(8, i).getContents());
						gra.setStage(rs.getCell(9, i).getContents());
						
						ls.add(gra);
					}
				}
			}catch (IOException | BiffException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return ls;
		
	}

}
