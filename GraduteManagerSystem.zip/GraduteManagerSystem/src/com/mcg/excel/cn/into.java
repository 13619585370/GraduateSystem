package com.mcg.excel.cn;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mcg.cn.model.Gradute;

public class into {
    String sql="insert into Gradute(stuNum,stuName,password,sex,major,gradeClass,address,phoneNum,politicsSta,stage) "
    		+ "values(?,?,?,?,?,?,?,?,?,?)";
    
    db data=new db();
    public PreparedStatement pstmt=null;
    public Boolean insertexcel(Gradute gra){
    	Boolean jiaqi=false;
    	
    	try {
			pstmt.setString(1, gra.getStuNum());
			pstmt.setString(2, gra.getStuName());
			pstmt.setString(3, gra.getPassword());
			pstmt.setString(4, gra.getSex());
			pstmt.setString(5, gra.getMajor());
			pstmt.setString(6, gra.getGradeClass());
			pstmt.setString(7, gra.getAddress());
			pstmt.setString(8, gra.getPhoneNum());
			pstmt.setString(9, gra.getPoliticsSta());
			pstmt.setString(10, gra.getStage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jiaqi;
    	
    }
}
