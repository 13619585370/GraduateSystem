var xmlhttp;
function createXMLHttpRequest(){
	if(window.XMLHttpRequest){
		xmlhttp=new XMLHttpRequest();
		
	}else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
}

function deleteGradute(value){
	createXMLHttpRequest();
	var message="id="+value;
	var url="graduteDelete";
	xmlhttp.open("POST",url,false);
	xmlhttp.onreadystatechange=callback;
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xmlhttp.send(message);
	return false;
}

function callback(){
	if(xmlhttp.status==200 &&xmlhttp.readyState == 4){
		//alert("3");
		//window.location.href="admin/graInfo/graChange.jsp";
	}
}

